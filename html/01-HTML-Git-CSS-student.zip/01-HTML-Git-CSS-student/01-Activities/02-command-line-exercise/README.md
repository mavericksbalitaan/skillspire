# 📖 Use Command-Line Commands to Create Directory and File

*Use the command line to create a directory and file on my computer. 

## Acceptance Criteria

1. Create a new directory named `first-day` using the command line.

2. Once you have created the directory `first-day` create a file inside it named `index.html`. The file should also be created using command-line commands.

## 📝 Notes

Refer to the documentation: 

[MDN Web Docs on basic built-in terminal commands](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Understanding_client-side_tools/Command_line#Basic_built-in_terminal_commands)

---

## 💡 Hints

What command can you use to list the contents of a directory? How can you use this command to check your work?

## 🏆 Bonus

If you have completed this activity research the following: 

* Which command do you use to copy or move files?

