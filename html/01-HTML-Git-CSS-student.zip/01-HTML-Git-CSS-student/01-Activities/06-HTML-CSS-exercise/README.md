# 🏗️ Create a Webpage Using HTML 

* As a student, I want to create a biography page that includes an image, a paragraph about me, and my contact information.

## Acceptance Criteria

1. The main header should read "Student Bio". 

2. Create a section that includes a name, an image, and a paragraph.

3. Create a second section that includes a subheader labeled "Contact Info" and a list that includes links to my email, GitHub, and portfolio.

* Check to make sure that the finished page matches the mockup. 

4. Next add a style sheet 

5. change the background to black or a dark color

6. change the text to a white or a light color

## Assets
You finished webpage should match the following:

![Webpage titled "Student Bio" features "Your Name" heading, a spot for an image and bio, and a "Contact Info" section.](./assets/image-1.png)

You can use this [placeholder image](https://via.placeholder.com/200).

---

## 💡 Hints

How can you use header elements to define the most important heading and the subheaders? How will using different header elements impact the size of the text?


## 🏆 Bonus

If you have completed this activity, research the following:
* What are the advantages of using semantic elements in your HTML? 

