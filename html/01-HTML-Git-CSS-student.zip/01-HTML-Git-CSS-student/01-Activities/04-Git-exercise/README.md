# 📖 Create a New GitHub Repository

Work with a partner to implement the following user story:

Create a new GitHub repository and add an HTML file to it.  

## Acceptance Criteria

1. Created a new repository named `first-day-repo` using the GitHub user interface.

2. Clone the `first-day-repo` to my local machine.

3. Use command-line commands to navigate into the `first-day-repo` directory.

4. Use command-line commands to create an `index.html` file.

5. Commit your changes using Git commands.

6. Push the changes to the remote repository. 

## 📝 Notes

Refer to the documentation: 

[GitHub Docs on creating a repo](https://docs.github.com/en/github/getting-started-with-github/create-a-repo)

[GitHub Docs on cloning a repository](https://docs.github.com/en/github/creating-cloning-and-archiving-repositories/cloning-a-repository)

---

## 💡 Hints

What command can you use to list the contents of a directory? How can you use this command to check your work?

## 🏆 Bonus

If you have completed this activity, research the following:

* What are the `git fetch` and `git merge` commands? 

U
