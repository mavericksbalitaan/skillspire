## Create a file named index.html

## Press and hold shift and the number ! key to get the boilerplate html code.

## Add an h1 tag that will store the name of a tv show

## Add an unordered list with the names of a few of the show's stars or characters

## Add a p tag with a few sentences explaining what the show is about.