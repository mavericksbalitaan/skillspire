* Use the code from the previous exercise.

* Add css styling based on the image in the assets folder.