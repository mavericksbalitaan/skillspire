* Create a biography page that includes an image, a paragraph about me, and my contact information. 

* Use the image in the assets folder as reference.

* Try to make your page look like the example image.
