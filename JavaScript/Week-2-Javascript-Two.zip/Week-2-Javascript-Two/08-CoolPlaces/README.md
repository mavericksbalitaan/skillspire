
### Instructions

* Follow the instructions provided in the file to `console.log` each of the names in the `city` variable.

* **HINT:** You should be repeating the same line 4 times.
