Modify the code so that it uses `console.log` instead of alerts to display messages.

Be able to discuss the difference between using `console.log` and `alert`.
