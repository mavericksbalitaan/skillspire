### Instructions

* Take a look at the html file, research if you are stumped. As a hint, look into the phrase "javasript for loop."
