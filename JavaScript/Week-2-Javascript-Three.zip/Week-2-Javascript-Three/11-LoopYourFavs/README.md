### Instructions

* Run the program in the file above.

* Then fill in the missing comments for each line of code.

* Make sure you can fully explain what each line means.

* Be prepared to share with the class!
