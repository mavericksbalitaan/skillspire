### File

* _None_

### Instructions

* Starting from scratch, create a `for` loop that console logs the following lines:

```
I am 0
I am 1
I am 2
I am 3
I am 4
```

* **NOTE:** Don't use an array!
