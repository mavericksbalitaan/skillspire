### File

* _None_

### Instructions

* Spend some time outlining all the steps and conditions that go into a single game of rock paper scissors.

* Try to break it down into steps that you could code out.

* Think of basic elements like loops, if-else statements, arrays, alerts, etc.

* Be prepared to share your outlines approach.


