### Instructions

* This html files includes inline javascript. You can open this file as you normally would: by copying the path of the .html file and opening it up in your browser. Once you do so follow the instructions below:

* Open the file in Chrome.

* Try to explain what is happening in the code. 

* Use comments to explain what is happening.


* **HINT:** We haven't discussed JavaScript before, but a big part of being a developer is learning on the fly!
