// TODO: What will the following line of code log?
console.log(window);

// TODO: What will the following line of code log?
console.log(window.document);

// TODO: What will the following line of code log?
console.log(document.documentElement);

// TODO: What will the following line of code log?
console.log(document.head);

