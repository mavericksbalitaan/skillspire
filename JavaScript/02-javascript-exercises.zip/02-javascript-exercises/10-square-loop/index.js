// Create a function that squares every number in the array.  

const nums = [1,2,3,4,5];
