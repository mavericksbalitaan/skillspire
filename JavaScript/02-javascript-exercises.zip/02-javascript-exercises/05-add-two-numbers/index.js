// INSTRUCTIONS:
// Create a function that returns the sum of two numbers.
// Numbers can be positive or negative.
// Should return a number.

function sum(a, b){
    
    //write your code here

}

c=


function yearBorn(age, currentYear){
    
    //write your code here

}

