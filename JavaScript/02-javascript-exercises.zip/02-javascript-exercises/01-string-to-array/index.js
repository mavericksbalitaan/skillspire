// INSTRUCTIONS:
// Create a function that converts a string to an array of individual words.
// The output should be an array.

// ***Bonus***
// Convert a number to a string

//Convert an array to a string


function strArr(str) {
    
}

let aString = "Today is Saturday"





