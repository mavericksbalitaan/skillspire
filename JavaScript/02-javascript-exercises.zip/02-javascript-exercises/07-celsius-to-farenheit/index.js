//Write a function that converts the Celsius temperature to Fahrenheit. 
function celToFahr(cel){

    //write your code here

}

