// Write a function that takes in a person's age and determines if they are old enough to vote.
// The function should return a boolean value.
