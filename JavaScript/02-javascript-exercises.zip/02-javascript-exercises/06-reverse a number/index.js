// INSTRUCTIONS:
// Create a function that takes in a number and reverses it.
// The output should be a number.

function reverseNum(num){
    
    //write your code here

}


