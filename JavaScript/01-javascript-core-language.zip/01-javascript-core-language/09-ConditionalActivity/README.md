### File

* *None*

### Instructions

* Create a webpage (from scratch) that asks users if they would like see Titanic 2.

* If they respond with "yes", write the following to the page: "Cool! Here's two tickets"

* If they respond with "no", write the following to the page: "Get out of my line"

* **BONUS:** Ask what the user’s how much money they have. If they have over $100, alert the following: "You may board this ship"

* **HINT:** You will need to use `document.write()` 
