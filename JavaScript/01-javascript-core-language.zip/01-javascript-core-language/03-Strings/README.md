### Instructions

1. Fill out the missing variables in this file.

2. Open in Chrome to check out the results

HINT:

* You should see a series of alerts.

* Look at the code and see if you can understand what is happening.
