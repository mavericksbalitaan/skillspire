### File

* *None*

### Instructions

* Create a website that accomplishes the following:

  * Create an array of your favorite foods.

  * With a prompt, ask the user's favorite food.

  * If it's one of your favorites, alert: "OMG! I love that too!"

  * If it's not, alert: "Ew! I don't like that"

  * **HINT:**  You will need to research how to use `.indexOf()`.

  * **HINT:** You will need to research how to use `.toLowerCase()`.
