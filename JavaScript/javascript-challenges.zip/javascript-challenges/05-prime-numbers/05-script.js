// Create a function that accepts a number as an argument and returns all the prime numbers up to that number.
// I.e. if given the number 9, your function should return 2, 3, 5, 7