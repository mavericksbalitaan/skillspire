// Write a function that checks if a given year is a leap year.
// Your function should return a boolean value.