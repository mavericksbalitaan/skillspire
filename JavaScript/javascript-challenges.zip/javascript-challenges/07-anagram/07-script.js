// Create a function that accepts two strings and checks if they are anagrams. Your function should return a boolean value.
// (fyi: an anagram contains the same characters but in a different order).
// For example: "cat" and "act" are anagrams