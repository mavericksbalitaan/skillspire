// Write a function that takes two numbers as arguments and returns their sum.


function sumTwoNums() {
    
}