// Create a function that accepts a number and returns an array of its prime factors.

