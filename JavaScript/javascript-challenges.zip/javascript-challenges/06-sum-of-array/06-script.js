// Create a function that accepts an array of numbers and returns the sum of all the numbers in the array.
// I.e. if given [4, 25, 337] your function should return 366