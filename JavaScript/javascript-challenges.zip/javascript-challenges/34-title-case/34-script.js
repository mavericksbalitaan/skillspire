// Write a function that takes an array of strings and capitalizes the first letter of each word.
// Input is an array and output is an array