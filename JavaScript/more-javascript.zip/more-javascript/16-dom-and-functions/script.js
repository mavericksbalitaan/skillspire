var numOne = document.getElementById("num-one");

console.log(numOne)

var numTwo = document.getElementById("num-two");
var sum = document.getElementById("add-sum");

numOne.addEventListener("input", add);
numTwo.addEventListener("input", add);

function add(){
    let one = parseFloat(numOne.value) || 0;

    console.log(one)

    let two = parseFloat(numTwo.value) || 0;
    
    sum.innerHTML = "The Sum is " + (one + two);
  }

  let multiplierOneElement = document.querySelector("#multiplierOne")
  let multiplierTwoElement = document.querySelector("#multiplierTwo")

  multiplierOneElement.addEventListener("input", multiply);
  multiplierTwoElement.addEventListener("input", multiply);


  console.log(multiplierOneElement.value)

  let product = document.querySelector("#multiplication-result")


  function multiply(){
    let firstMultiplier = parseFloat(multiplierOneElement.value) || 0
    let secondMultiplier = parseFloat(multiplierTwoElement.value) || 0

    product.innerHTML = "The result is " + (firstMultiplier * secondMultiplier)

  }

  multiply();
  // create a subtract function
 
  // create a multiply function

  //create a divide function