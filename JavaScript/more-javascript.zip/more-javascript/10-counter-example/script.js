const decrementEl = document.querySelector('#decrement');
const incrementEl = document.querySelector('#increment');
const currentCountEl = document.querySelector('#currentCount');

let count = 0;

currentCountEl.innerHTML = count;

function incrementCount(){
    count++;
    currentCountEl.innerHTML = count;
    console.log("click")
}

function decrementCount(){
    count--;
    currentCountEl.innerHTML = count;
    console.log("click")
}


incrementEl.addEventListener("click", incrementCount);
decrementEl.addEventListener("click", decrementCount)
