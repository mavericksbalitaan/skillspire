// create a variable called boxElement
// In your html file create a div with an id of box;
// use the getElementById method to target the div you just created
// add the innerHTML property and assign it your first and last name.

