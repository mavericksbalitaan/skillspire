// INSTRUCTIONS:
// Create a function that takes in a string and puts all of its letters in alphabetical order
// Output should be a string

// *** Bonus
// 1. Create a function that takes in array of numbers and puts them in numerical order.


function alphabeticalOrder(str) {
    return;
}

console.log(alphabeticalOrder("Monica"))