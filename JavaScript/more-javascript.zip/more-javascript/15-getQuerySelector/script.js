// create a variable called mainSectionElement
// In your html file create a div with an id of main-section;
// use the querySelector method to target the div you just created
// add the innerHTML property and assign it a string that says: Today is a good day to do some javascript




let mainSectionElement = document.querySelector("#main-section").innerHTML = "Today is a good day to do some javascript";