// Logs the document object
let greeting = document.getElementById("greeting").innerHTML = "Hi, welcome to my website. 👋";
