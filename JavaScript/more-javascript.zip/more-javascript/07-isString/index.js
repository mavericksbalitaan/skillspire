// INSTRUCTIONS:
// Create a function that checks if an input is a string or not.
// Return true if it is a string and false if not


// ***Bonus***
// 1. check if a value is a number or not.
// Return true if it is a string and false if not

// If you still have time, create a function that takes in any value.
// Check it's data type and return the data type.


function isString(str){


}

console.log(isString("Monica"))