Connect Sequelize to the database using the `dotenv` npm package.

