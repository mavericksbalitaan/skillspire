const Sequelize = require('sequelize');

// Enable access to .env variables


// Use environment variables to connect to database
const sequelize = new Sequelize(
  // db_name
  // db_user
  // db_password
  {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306
  }
);

module.exports = sequelize;
