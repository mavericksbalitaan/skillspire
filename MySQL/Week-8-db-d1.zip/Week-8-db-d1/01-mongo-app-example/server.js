const { application } = require('express');
const express = require('express');

const server = express();

const peopleRouter = express.Router()

const people = require('./src/data/people.json')

const adminRouter = require('./src/routers/adminRouter');

server.set('views', './src/views');

server.set('view engine', 'ejs');

server.use('/admin', adminRouter)

peopleRouter.route('/').get((req, res) => {
      res.render('people', {
        people
      })
    })

peopleRouter.route('/:id')
.get((req, res) => {
    let id = req.params.id
    console.log(id)
    res.render('person', { person: people[id - 1] })
})


server.use('/people', peopleRouter)

server.get("/", (req, res) => {

    res.render('index', {title: "Welcome to the Home Page", data: ["Leanne Graham", "Ervin Howell", "Clementine Bauch", "Patricia Lesbsack", "Chelsey Dietrich", "Dennis Schulist", "Kurtis Weissnat", "Nicholas Runolfsdottir V", "Glenna Reichert", "Clementina DuBuque"]})
})

server.get("/about", (req, res) => {
    res.render('about', {title: "Welcome to the About Page"})
})
let PORT = 3009;

server.listen(PORT, () => {
    console.log("Listening on ", PORT)
})