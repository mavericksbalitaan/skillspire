const express = require('express');
const { MongoClient } = require('mongodb');
const people = require('../data/people.json')

const server = express();

const adminRouter = express.Router();

adminRouter.route('/').get((req, res) => {
    const url = 'mongodb+srv://mo:typewriter33@cluster0.ov11fm3.mongodb.net/?retryWrites=true&w=majority';
    const dbName = 'cluster0'
    

    (async function mongo(){
        let client;
        try {
            client = await MongoClient.connect(url);
            const db = client.db(dbName);

            const response = await db.collection('people').insertMany(people)
            res.json (response)

        } catch (error) {
            console.error("db error")
        }
    })
})

module.exports = adminRouter;