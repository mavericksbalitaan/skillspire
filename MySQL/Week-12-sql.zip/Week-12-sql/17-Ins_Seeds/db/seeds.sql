INSERT INTO courses (id, course_title, course_description, active)
VALUES (001, "Algebra I", "Linear equations, inequalities, functions, and graphs", true),
       (002, "Pre-Calculus", "Polynomials, Complex Numbers, Vectors", true),
       (003, "Calculus I", "Limits, Differentiation, Derivatives", true),
       (004, "Euclidean Geometry", "Intuitively Appealing Axioms Galore", false);
       
