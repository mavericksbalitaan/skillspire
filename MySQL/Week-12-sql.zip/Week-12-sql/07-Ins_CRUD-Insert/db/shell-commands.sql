SELECT * FROM produce;

-- Check if Database in Use ---
SELECT DATABASE();
