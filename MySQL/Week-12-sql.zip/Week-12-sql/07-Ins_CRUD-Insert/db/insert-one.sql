-- Insert row into produce table --
INSERT INTO produce (id, name)
  VALUES (1, "apple");
