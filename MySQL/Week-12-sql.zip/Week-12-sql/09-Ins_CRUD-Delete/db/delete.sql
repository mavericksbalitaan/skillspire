DELETE FROM produce
WHERE id = 2;
