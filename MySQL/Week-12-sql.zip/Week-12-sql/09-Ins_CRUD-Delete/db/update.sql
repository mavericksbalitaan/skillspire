UPDATE produce
SET name = "strawberry"
WHERE id = 1;
