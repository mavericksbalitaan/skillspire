INSERT INTO products (product_name, category_name)
VALUES ("spinach", "produce"),
       ("peanut butter", "staples"),
       ("peas-canned", "canned goods"),
       ("ice cream", "frozen"),
       ("potato chips", "snacks");
       
