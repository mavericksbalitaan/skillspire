-- Drops the sample_db if it exists currently --
DROP DATABASE IF EXISTS sample_db;
-- Creates the sample_db database --
CREATE DATABASE sample_db;
