INSERT INTO students (first_name, last_name, enrolled)
VALUES ("Elliot", "Smith", false),
       ("Amira", "Afzal", true),
       ("Christoper", "Lee", true),
       ("Verónica", "Rodriguez", false),
       ("Igor", "Stein", true);
       
