UPDATE fiction
SET name = "Candide";
