{
  "GET /students": {
    "desc": "returns all students",
    "response": "200 application/json",
    "data": [{}, {}, {}]
  },

  "GET /students/:id": {
    "desc": "returns one student respresented by its id",
    "response": "200 application/json",
    "data": {}
  },

  "POST /students": {
    "desc": "create and returns a new student uisng the posted object as the student",
    "response": "201 application/json",
    "data": {}
  },

  "PUT /students/:id": {
    "desc": "updates and returns the matching student with the posted update object",
    "response": "200 application/json",
    "data": {}
  },

  "DELETE /students/:id": {
    "desc": "deletes and returns the matching student",
    "response": "200 application/json",
    "data": {}
  }
}