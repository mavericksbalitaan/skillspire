const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const server = express();
const PORT = 3000;

let cars = [];
let id = 0;

server.set('views', './src/views');
server.set('view engine', 'ejs');

server.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
server.use(bodyParser.json())

server.get("/", (req, res) => {
    res.render("index", {cars: cars})
})

// create your get route here



server.get("/register", (req, res) => {
   res.render("register")
})

server.post("/register", (req, res) => {
    let car = req.body
    id++;
    car.id = id + ''
    cars.push(car)
    res.json(req.body)
 })

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})