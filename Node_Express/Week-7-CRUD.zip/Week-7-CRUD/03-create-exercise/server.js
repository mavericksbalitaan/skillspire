// import express


// import ejs


// bodyParser


// initiate your server


// listen on a port


// add middleware


// create an array for your "synthetic database"


// create a variable to store/track your ids


// create a home route and send a simple message


// create a get route to read api data


// create a get route to render the register page


// have your server listen on your port. Console.log() to confirm that your server is running.
