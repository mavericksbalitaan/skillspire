const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const server = express();
const PORT = 3001;

let students = [];
let id = 0;

server.set('views', './src/views');
server.set('view engine', 'ejs');

server.use(bodyParser.urlencoded({ extended: false }))

server.use(bodyParser.json())

// Create a home route
// render your home page and render all of the students
server.get("", (req, res) => {
})

server.get("", (req, res) => {
   // create the route that renders the students in json format

})

server.get("", (req, res) => {
// create the route for rendering the register page
})

server.post("/register", (req, res) => {
    // write the logic for adding a student to the student roster
 })

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})