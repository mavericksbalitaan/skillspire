const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const server = express();
const PORT = 3001;

let gradebook = [];
let id = 0;

server.set('views', './src/views');
server.set('view engine', 'ejs');

server.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
server.use(bodyParser.json())

server.get("/", (req, res) => {
    res.render("index", {gradebook: gradebook})
})

server.get("/api/grades", (req, res) => {
    res.json(gradebook)
})


server.get("/grades", (req, res) => {
   res.render("register")
})

server.post("/grades", (req, res) => {

})

server.update("/grades/:id", (req, res) => {
    var update = req.body;
    if (update.id){
    
    }
})

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})