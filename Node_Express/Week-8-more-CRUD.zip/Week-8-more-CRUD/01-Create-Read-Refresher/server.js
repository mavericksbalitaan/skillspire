const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const server = express();
const PORT = 3001;

let students = [];
let id = 0;

server.set('views', './src/views');
server.set('view engine', 'ejs');

server.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
server.use(bodyParser.json())

server.get("/", (req, res) => {
    res.render("index", {students: students})
})

server.get("/students", (req, res) => {
    res.json(students)
})


server.get("/register", (req, res) => {
   res.render("register")
})

server.post("/register", (req, res) => {
    let student = req.body
    id++;
    student.id = id + ''
    students.push(student)
    res.json(req.body)
})

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})