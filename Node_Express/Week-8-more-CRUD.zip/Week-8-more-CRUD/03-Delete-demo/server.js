const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const server = express();
const PORT = 3033;

let gradebook = [];
let id = 0;

server.set('views', './src/views');
server.set('view engine', 'ejs');

server.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
server.use(bodyParser.json())

server.get("/", (req, res) => {
    res.render("index", {gradebook: gradebook})
})

server.get("/api/grades", (req, res) => {
    res.json(gradebook)
})


server.get("/grades", (req, res) => {
   res.render("register")
})

server.post("/grades", (req, res) => {
    let student = req.body
    id++;
    student.id = id + ''
    students.push(student)
    res.json(req.body)
 })

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})