let students = ["Natalie", "Felix", "D'Andre", "Lucian", "David"]

function classInfo(arr){

   for (let i = 0; i < arr.length; i++) {
    console.log(`${arr[i]} knows javascript!`)
   }

}

classInfo(students);