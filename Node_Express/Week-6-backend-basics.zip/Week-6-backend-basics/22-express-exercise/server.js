// 1. require the express package. Don't forget to install the package
const express = require('express');
const app = express();

const handlebars = require('express-handlebars')

// 2. intiate express and save it to a variable called app

app.engine('handlebars', handlebars({
    defaultLayout: 'main',
    layoutsDir: __dirname + '/views/layouts/'
}))

app.set('views', path.join(__dirname, 'views')); // Here you give express the information that it has to look at all files that are in the path /views
app.set('view engine', 'handlebars'); // Here you say express that you are using handlebars to build your website

app.get('/home', function (req, res, next) { // That's a simple GET request (This GET request gets triggered when you enter http://localhost/home for example)
        return res.render('home');  // Here we render the index.handlebars file (that is in the /views folder)
});

// 3. create a get route for the base url
// app.get("/", (request, response) => {
//     // 4. inside of your get route use res.send to send a string to the browser

//     response.render('home')
// })

app.get("/about", (request, response) => {

    response.send("...from the ABOUT page")
});


// 5. add a listener to your app on port 3000. 
let PORT = 8080;

app.listen(PORT, () => {
    // 6. Inside of your listener console.log() a message confirming what port your app is listening on
    console.log(`PORT ${PORT}`)
})

//7. After you install your dependencies add a git ignore file