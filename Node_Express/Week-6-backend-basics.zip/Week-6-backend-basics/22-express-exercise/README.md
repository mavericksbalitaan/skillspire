### Create a simple express server
