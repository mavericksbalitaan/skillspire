// 1. create an array of numbers
// 2. Create a function called cubed
// 2. Inside of the function create a four loop that cubes each number
// 3. Use node to run the entire file.