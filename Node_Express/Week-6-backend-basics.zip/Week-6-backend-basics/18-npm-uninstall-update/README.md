### To uninstall:
    npm uninstall <package name>


### To update:
    npm update <package name>
    (don't forget to specify ~ of ^)