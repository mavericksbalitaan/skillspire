const express = require('express');

const server = express();

server.get('/', (req, res) => {
    res.send("Home route")
})

let PORT = 3030;

server.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`)
})