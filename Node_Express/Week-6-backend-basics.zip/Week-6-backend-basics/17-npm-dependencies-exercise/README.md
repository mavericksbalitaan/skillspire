### 1. create a package json

### 2. add the following packages:

    https://www.npmjs.com/package/express

    https://www.npmjs.com/package/mongoose

    https://www.npmjs.com/package/mongodb

    https://www.npmjs.com/package/inquirer