1. Let's start building our project. 
3. We'll need to run the command npm init -y to create our package.json() file.
2. Create file called server.js. Inside of that file require express
3. create a variable called server and instantiate express.
4. create a home route and render 'Home Page' at this route.
5. create a variable called PORT and assign it the value 3000.
6. add a console.log() to confirm that your server is running on port 3000.

***HINT*** Don't forget to use npm to install your dependencies