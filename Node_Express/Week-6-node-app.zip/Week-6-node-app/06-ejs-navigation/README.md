### 1. Add navigation from the home page to about page.

### 2. Add navigation from the about page to home page.