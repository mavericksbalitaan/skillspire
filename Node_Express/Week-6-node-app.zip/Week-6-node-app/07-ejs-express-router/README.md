### 1. In the server.js lets require express router (This will be saved in a variable called peopleRouter)

### 2. We'll create a peopleRouter with a get call and return a string

### 3. Next we'll use middleware to create a connection to our peopleRouter

### 3. We need to create a way to dynamically create a page and a route for each person. Create a get route that will take us to 'localhost:3000/people/1

### 4. send a string with the text '...from people at index 1'



