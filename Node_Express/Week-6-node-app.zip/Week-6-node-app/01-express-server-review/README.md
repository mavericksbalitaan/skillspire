This directory has a package.json file with no node_modules folder.

Run npm install to install the dependencies locally.