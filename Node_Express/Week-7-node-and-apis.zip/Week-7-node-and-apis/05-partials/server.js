const express = require('express');
const fetch = require('node-fetch')

require('dotenv').config()

// CHECK THIS OUT

const server = express();
const PORT = 3010;

const API_KEY = process.env.API_SECRET


server.set('views', './src/views');
server.set('view engine', 'ejs')

server.get("/", (req, res) => {
    fetch(
        `https://api.giphy.com/v1/gifs/trending?api_key=${API_KEY}&limit=25&rating=g`
      )
        .then((response) =>  response.json())
        // .then((data) => console.log(data))
        .then((data) => res.render('index', { data: data.data }))
        .catch((error) => console.error('Error from the api: ', error));
})

server.get("/about", (req, res) => {
    res.render('about')
})

server.get("/contact", (req, res) => {
    res.send("contact page")
})

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})