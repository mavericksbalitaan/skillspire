const express = require('express');

const ejs = require('ejs');
const fetch = require('node-fetch')

const server = express();
const PORT = 3001;


server.set('views', './src/views');
server.set('view engine', 'ejs')

// get route & fetch here
// in your fetch console.log the response. 
// Once you're comfortable with the data delete the console


server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})