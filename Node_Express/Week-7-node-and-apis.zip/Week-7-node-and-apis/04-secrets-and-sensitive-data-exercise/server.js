const express = require('express');
const fetch = require('node-fetch')
// install the dotenv npm package


// console.log(process.env) for fun

const server = express();
const PORT = 3001;

// create a variable to store a reference to your API KEY



server.set('views', './views');
server.set('view engine', 'ejs')

server.get("/", (req, res) => {
   // your code goes here
})

server.listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
})