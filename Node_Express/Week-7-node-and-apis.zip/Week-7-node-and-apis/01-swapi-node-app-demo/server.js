const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mongodb = require('mongodb');

const app = express();
const MongoClient = mongodb.MongoClient;
const url = 'mongodb+srv://monicah2:bobdylan33@db1.zjskuo0.mongodb.net/?retryWrites=true&w=majority';

app.set('view engine', 'ejs');
app.set('views', './src/views');
app.use(bodyParser.urlencoded({ extended: true }));

MongoClient.connect(url, { useNewUrlParser: true }, function(err, client) {
  if (err) throw err;
  const db = client.db('myapp');

  app.get('/', function(req, res) {
    db.collection('items').find().toArray(function(err, items) {
      if (err) throw err;
      res.render('index', { items: items });
    });
  });

  app.get('/create', function(req, res) {
    res.render('create');
  });

  app.post('/create', function(req, res) {
    const item = { name: req.body.name };
    db.collection('items').insertOne(item, function(err, result) {
      if (err) throw err;
      res.redirect('/');
    });
  });

  app.get('/edit/:id', function(req, res) {
    const id = req.params.id;
    db.collection('items').findOne({ _id: mongodb.ObjectId(id) }, function(err, item) {
      if (err) throw err;
      res.render('edit', { item: item });
    });
  });

  app.post('/edit/:id', function(req, res) {
    const id = req.params.id;
    const item = { name: req.body.name };
    db.collection('items').updateOne({ _id: mongodb.ObjectId(id) }, { $set: item }, function(err, result) {
      if (err) throw err;
      res.redirect('/');
    });
  });

  app.get('/delete/:id', function(req, res) {
    const id = req.params.id;
    db.collection('items').deleteOne({ _id: mongodb.ObjectId(id) }, function(err, result) {
      if (err) throw err;
      res.redirect('/');
    });
  });

  app.listen(3000, function() {
    console.log('Server started on port 3000');
  });
});
