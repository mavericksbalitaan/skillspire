Go to: https://makeup-api.herokuapp.com/ and read through the documentation.

Create an app that calls the api and renders data for only of the Fenty Makeup.

Render these items from the api and display them as you'd like:
name
description
price
image



*** BONUS ***
If you are able to successfully render that data and you have still have time or would like an additional challenge do the following steps:

Add search functionality.

Allow users to search for a particular type of makeup, 
i.e. foundation, lipstick etc.