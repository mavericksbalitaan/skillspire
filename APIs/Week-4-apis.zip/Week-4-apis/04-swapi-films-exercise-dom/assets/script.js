// NOTICE THE getFilms() function. 
// Before you begin working call your function at the bottom of this File.

let filmWrapperEl = document.querySelector("#films-wrapper");

function getFilms() {

    // add the appropriate endpoint
    const apiURL = 'https://swapi.dev/api/films'

    fetch(apiURL)
    .then((response) => response.json())
    .then((data) => {
        // check the console to see the data
        console.log(data.results)

        data.results.map(film => {

            // DON'T TOUCH THIS SECTION
            // dynamically creates and styles each 'film card'
            let filmCard = document.createElement('div');
            filmCard.style.border = '1px solid yellow'
            filmCard.style.width = '400px';
            filmCard.style.height = '400px';
            filmWrapperEl.appendChild(filmCard);


            // dynamically creates the element that displays the film title
            let filmName = document.createElement('h3');
            filmName.style.color = "#FFF";
            filmName.textContent = film.title
            filmCard.appendChild(filmName);
            

            // ADD YOUR YOUR CODE HERE
            // 1. dynamically create a an h3 element and assign it to a variable called filmProducers .

            // 2. give filmProducers some styling. The font color should be white.

            // 3. assign the textContent of filmProdicers the value that points to producers from the api.

            // 4. append the filmProducers element to filmCard element (use appendChild)

            


        })


    });
}

// call your get films function here

getFilms()