let characters = document.querySelector("#characters-wrapper");

function getCharacters() {
    // endpoints 
    const apiURL = 'https://swapi.dev/api/people/'

    fetch(apiURL)
    .then((response) => response.json())
    .then((data) => {
        console.log(data)

        let chars = data.results;

        console.log(chars.map(x => x.name))
        
        chars.map(char => {

            console.log("char", char)
            let characterName = document.createElement('h3');

            characterName.textContent = char.name
            characters.appendChild(characterName)
            console.log(characterName)
        })        
    });
}

getCharacters();