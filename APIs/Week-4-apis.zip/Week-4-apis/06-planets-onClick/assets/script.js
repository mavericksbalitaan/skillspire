// 1. Use your favorite document.method() to retrieve the html element with the id of 'planets-wrapper'
// set it equal to a variable named plants


// 2. create a variable called buttonEl that will be used to access your button element


function getPlanets() {
    // 3. Inside of the function called getMovies() create a variable called apiURL to store the url of the endpoint for Star Wars planets from the Star Wars API.



    // 4. Use the fetch() method to make a request to the Star War planet endpoint.

    
    // 5. Inside the second .then() create a variable called.

    // 6. use the map method to iterate over the results of your api call.

    // 7. dynamically create an h3 element that will store the planet names

    // 8. append your planets element to your planet wrapper

}



// 9. take your button element and add a click eventListener that fires when clicked and runs your getPlanets function




