let nameField = document.querySelector("#character-name");
let genderField = document.querySelector("#character-gender");
let birthYearField = document.querySelector("#character-birthyear");

let namebuttonEl = document.querySelector("#name-button")
let genderbuttonEl = document.querySelector("#gender-button")
let birthYearbuttonEl = document.querySelector("#birthyear-button")


function getName() {}

function getGender() {}

function getBirthYear() {}

namebuttonEl.addEventListener('click', getName);
genderbuttonEl.addEventListener('click', getGender);
birthYearbuttonEl.addEventListener('click', getBirthYear);

