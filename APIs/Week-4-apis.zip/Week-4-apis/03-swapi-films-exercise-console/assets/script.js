// 1. Create a function called getMovies
function getMovies(){





}

// 2. Inside of the getMovies() function create a variable called apiURL to store the url of the endpoint for Star Wars films from the Star Wars API.

// 3. Use the fetch() method to make a request to the Star War films endpoint.

// 5. Inside the second .then() console.log the data. 
// Open up the console to take a look at the data.
// You should see several attributes such as count, next, previous, and result

// 6. Next console.log() only the film data (hint: film data is located in the result array) 
// Need another hint? Check the bottom of this file for more.

// 7. Next use the map method to iterate over the array of films aka the results array.

    // 7a. Console.log() each movie object to see what is displayed. You should be using dot-notation.
    // 7b. Replace what you just console.log'd with a new console.log that accesses the movie title. Each title should be logged on its on line
    // 7c. Replace the last console.log() with a new console.log that logs the movies release year ONLY. To do this log the the release_year and use a string method to access the first 4 digits of the string.
           //Check the bottom of this file for a hing

// 4. Call the getFilms function here:

getMovies()













































// QUESTION 5 HINT to console.log() the film data only

//QUESTION 7c HINT there are several ways to acces the year. Once you have successfully console.log'd char.release_date. Look up the .slice() method.  