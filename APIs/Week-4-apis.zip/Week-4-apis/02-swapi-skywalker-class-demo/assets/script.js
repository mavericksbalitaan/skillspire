let nameField = document.querySelector("#character-name");
let gender = document.querySelector("#gender")
let birthYear = document.querySelector("#birthYear")


function getCharacters() {

}

getCharacters();