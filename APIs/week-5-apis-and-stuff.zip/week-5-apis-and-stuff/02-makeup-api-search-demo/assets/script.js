let previousSearchEl = document.querySelector("#previous-search");
let makeupContainerEl = document.querySelector("#makeup-container");


function getMakeup() {

   
    let inputVal = document.querySelector("#input-text").value;;
    
    console.log(inputVal)

  
    localStorage.setItem("prevMakeupSearch", inputVal);


    let API_URL = "https://makeup-api.herokuapp.com/api/v1/products.json?brand_type=" + inputVal


    fetch(API_URL)
        .then(response => response.json())
        .then(data => {
            console.log(data)

          // render previous search
          let prevMakeupSearch = localStorage.getItem("prevMakeupSearch");

          let button = document.createElement("h3");
          
          button.innerHTML = `<a href="${API_URL}">${prevMakeupSearch}</a>`
          
          previousSearchEl.appendChild(button)

          inputVal.value = "";


          // render gifs
          data.map(item => {

            let brand = document.createElement("h4");
            let name = document.createElement("h4");
            let hr = document.createElement("hr");

       
            console.log(item.brand)


            brand.textContent = `brand: ${item.brand}`
            name.textContent = `name: ${item.name}`


            makeupContainerEl.append(brand)
            makeupContainerEl.append(name)
            makeupContainerEl.append(hr)

          

          })


        })



}

getMakeup()