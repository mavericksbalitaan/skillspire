let showContainerEl = document.querySelector("#show-container");

function getShows(){

    let API_URL = "https://api.tvmaze.com/search/shows?q="

    fetch(API_URL)
        .then((response) => response.json())
        .then((data) => {
    
          console.log(data);

          let shows = data.map(show => {

          // render tv shows

          })


        })

  


    }

getShows()
