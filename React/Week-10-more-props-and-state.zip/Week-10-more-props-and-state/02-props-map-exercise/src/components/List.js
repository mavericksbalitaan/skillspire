import React from 'react';

const List = ({ users }) => {
  return (
    <div>
      <h1>Random Users:</h1>
      <ul>
       
      </ul>
    </div>
  );
}

export default List;
