// add the useState hook
import React from 'react';

const Counter = () => {
    // create your state variables and set your state.
    

    //add your functions here.
   

    return(
       // render your counter and buttons here

       
    )
}

// export your Counter here.