import React, { useState } from 'react';

const Form = () => {

    const [name, setName]= useState('');

    return(
        <>
        <form>
            <input placeholder="enter Name"  name="name" onChange={e => setName(e.target.value)}/>
            <p>{name}</p>
        </form>
        </>
    )
}

export default Form;