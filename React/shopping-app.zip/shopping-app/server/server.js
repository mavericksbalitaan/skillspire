const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
// const cors = require('cors');

const User = require('./models/userModel')

const app = express();
const PORT = 3001;

// cors();

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

const dbConnection = async () => {
    await mongoose.connect('mongodb+srv://monicah4:J0eLZGEIH9flUhDN@my-node-apps.mvufax0.mongodb.net/?retryWrites=true&w=majority')

    console.log(`Connected to Mongo!`)
}

dbConnection();

app.post("/api/sign-up", (req, res) => {

    bcrypt.hash(req.body.password, 10)
        .then((saltedPassword) => {
            const user = new User({
                userName: req.body.userName,
                email: req.body.email,
                password: saltedPassword
            })
            user.save()
            .then((result) => {
                res.status(201).send({
                  result,
                });
    
            })
    })   
})

app.post("/api/sign-in", (req, res) => {

    User.findOne({email: req.body.email})
        .then(user => {
            bcrypt.compare(req.body.password, user.password)
            .then((tempPassword) => {
                return res.status(200).send({message: "signed in!!!!", tempPassword})
            })
        })

})

app.listen(PORT, () => {
    console.log(`listening on port ${PORT}`);
})
