import React, {useState} from 'react';
import styled from "styled-components";
import axios from 'axios';


const About = () => {
  const [ userName, setUserName ] = useState("");
  const [ email, setEmail ] = useState("")
  const [ password, setPassword ] = useState("")

  const handleSubmit = (e) => {
    e.preventDefault();

    
    axios.post('http://localhost:3001/api/sign-in', {
      userName: userName,
      email: "email@email.com",
      password: "pazzword1234",
    })
    .then(result => console.log(result))

    setUserName('')
    setEmail('');
    setPassword('')
  }

  
  return (
    <div>
      <Heading>
      {/* <label for="USER NAME" /> */}
        <input placeholder="enter userName" type="text" name="userName" onChange={e => setUserName(e.target.value)} />
        {''}
        {/* <label for="EMAIL" /> */}
        <input placeholder="enter email" type="text" name="email" onChange={e => setEmail(e.target.value)} />
        {/* {''}
        <label for="PASSWORD" /> */}
        <input placeholder="enter password" type="text" name="password" onChange={e => setPassword(e.target.value)} />
        {''}
        <button onClick={handleSubmit}>submit</button>
      </Heading>
    </div>
  );
};

const Heading = styled.div`
  margin-top: 8rem;
  text-align: center;
  display: block;

  a:nth-of-type(1) {
    border-bottom: violet solid 2px;
  }
`;

export default About;
