// Add React & useState dependecies

const Counter = () => {
    // create count state variables. Initialize count to 0;
    
    
    // create an incrementCount function. Call the setCount function inside the function.
    


    // create a decrementCount function. Call the setCount function inside the function.
   
    


    return(
        <>
        {/* Render the count here: */}
       

        {/* Render the increment and decrement buttons here. Add a click handler on each function. */}
        
      
        </>
    )
}

export default Counter;