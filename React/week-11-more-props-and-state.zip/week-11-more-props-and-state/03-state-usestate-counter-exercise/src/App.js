import './App.css';
// import your Counter componenet

function App() {
  return (
    <div className="App">
      {/* add your counter comoponent */}
    </div>
  );
}

export default App;
