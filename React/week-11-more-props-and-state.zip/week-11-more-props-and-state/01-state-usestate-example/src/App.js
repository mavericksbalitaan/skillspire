import React, { useState } from 'react';
import './App.css';

function App() {

  const [name, setName] = useState("Monica");

  return (
    <div className="App">
      <h1>Good morning, {name}!</h1>
      <button
        type="button"
        onClick={() => setName("Beyonce")}
      >
        Update Greeting
      </button>
    </div>
  );
}

export default App;
