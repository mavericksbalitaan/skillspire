import React from 'react';
//import your List component
import Nav from './components/Nav';

// Import our list of users from users.js


export default function App() {
  return (
    <div>
      <Nav />
      {/* Render your List component here & Pass users array to the List component as a prop */}
    </div>
  );
}
