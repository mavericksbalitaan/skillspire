import React from 'react';


// pass your user info as props
const List = () => {
  
  return (
    <div>
      <h1>Random Users:</h1>
      <ul>
        {/* map over the users array and return each user as list item */}

      </ul>
    </div>
  );
}

export default List;
