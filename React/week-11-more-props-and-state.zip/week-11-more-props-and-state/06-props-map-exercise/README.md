1. Notice there are two files in the components folder. We'll be working with the List component.

2. In the List component pass in the props. 

3. Inside of the ul pass in the props.

4. Inside of the ul map over the props and return a <li> with the first name, last name, and usernam. (Don't forget to use a key )

5. Back in the App component import your List component.

6. Render your list component under the Nav component.

7. Pass in the users array to the List component as props.