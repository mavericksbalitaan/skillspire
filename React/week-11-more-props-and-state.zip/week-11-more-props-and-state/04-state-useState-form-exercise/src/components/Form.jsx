import React, { useState } from 'react';

const Form = () => {

    // create a state variables to store and update name, age, and username
    const [name, setName]= useState('');
    const [age, setAge]= useState('');
    const [userName, setUserName] = useState('mh3000');


    console.log("name", name);


    return(
        <>
        <form>
            {/* Render an input. Add a placeholder, name, onChange attributes */}
            <input />
            {/* Render the name variable here */}
            <p></p>

            {/* Render an input. Add a placeholder, name, onChange attributes */}
            <input />
            {/* Render the age variable here */}
            <p></p>


            {/* Render an input. Add a placeholder, name, onChange attributes */}
            <input />
            {/* Render the userName variable here */}
            <p></p>
        </form>
        </>
    )
}

export default Form;