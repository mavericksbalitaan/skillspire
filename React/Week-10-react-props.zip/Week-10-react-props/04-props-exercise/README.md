### Lets create a Madlibs game...again.

## This time we're going to use props.

1. Create a folder called components and inside of the components folder create a file callded Madlibs.

2. import React

3. create an arrow function called Madlibs, pass a parameter called props. (Don't forget to import it)

4. Inside of the return statement, between the fragments paste this snippet:

<p>In [year], president [famous person] declared the 4th Thursday of [month] as a national day of thanksgiving to celebrate [pluralNount1] and [pluralNoun2]<p>

5. Go to the App.js and import your Madlibs componenet.

6. Render your Madlibs component in the return statement.

7. Above your App.js component add 5 variables with these names: year, pluralNoun1, pluralNoun2, month, and famousPerson.

8. Still inside of your App.js component pass the year, pluralNoun1, pluralNoun2, month, and famousPerson props to the Madlibs component.

9. Go to your Madlibs component andreplace the words and square brackets with the correct syntax to pass the props.


