### Lets make a Thanksgiving Madlibs
# Create a Madlibs component in your component folder. 

# In your Madlibs component you're going to create 5 variables

# These variables should be placed above your Madlibs component (function) but below the imports.

# Assign the appropriate values to your madlibs

1. create a variable called pluralNoun1.
2. create a variable called month.
3. create a variable called year.
4. create a variable called famousPerson.
5. create a variable called pluralNoun2.

### Inside of the return statement in your madlibs component paste the following snippet. Replace the words in square brackets with your variables from the the previous step. 

<p>In [year], president [famous person] declared the 4th Thursday of [month] as a national day of thanksgiving to celebrate [pluralNount1] and [pluralNoun2]<p>

# Export your Madlibs component

# Inside of your App.js import your Madlibs component and render it in the return statement.



