import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          This is the App.js file
        </p>
      </header>
    </div>
  );
}

export default App;
