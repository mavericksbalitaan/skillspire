import './App.css';
import JSXVariables from './components/JSXVariables';

function App() {
  return (
    <div className="App">
    <JSXVariables />
   </div>
  );
}

export default App;
