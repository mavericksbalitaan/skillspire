import React from "react";

// create a variable called str and store the sentence "My dog ate my coding homework"
const str = "my dog ate my coding homework"
// create an arrow function called spongeBobCase that converts a str to all caps
let spongeBobCase = (str) => {
  return str.split(" ")
                .map(function(el) {
                  return el.split('')
                           .map(function(letter, idx) {
                             return idx % 2 === 0 ? letter.toLowerCase() : letter.toUpperCase();
                           })
                           .join('');
                })
                .join(' ')
              }
;

const JSXVariables = () => (
  <div className="main-container"> 
        {/* render the sentence to the screen */}
        <p>{str}</p>
        {/* print the number of letters in the string */}
        <p>{str.length}</p>
        {/* add a meme */}        
        <img src="https://i.kym-cdn.com/photos/images/original/001/253/025/34d.jpg" alt="spongbob mocking meme" />
        {/* use the spongeBobCase case function and pass it the string you created earlier */}
        <h1>SpongeBob Case: {spongeBobCase(str)}</h1>
  </div>
);

export default JSXVariables;
