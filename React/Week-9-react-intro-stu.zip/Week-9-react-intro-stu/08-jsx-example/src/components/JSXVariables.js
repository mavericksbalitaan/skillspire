import React from "react";

const JSXVariables = () => {
const name = "Leonardo DiCaprio";
const birthYear = 1974;
const currentYear = 2022;

  return (
    <div className="main-container">
      {/* This is a comment; notcie the syntax */}
      <h2>My name is {name}. But you can call me...</h2>
      <h1>THE KING OF THE WORLD</h1>
      <hr />
      <h2>I can do math: {currentYear + birthYear}.</h2>
      <h2>
        I can generate random numbers:
        {Math.floor(Math.random() * 10) + 1},
        {Math.floor(Math.random() * 10) + 1},
        {Math.floor(Math.random() * 10) + 1}.
      </h2>
      <h2>I can even reverse a string: {name.split("").reverse()}</h2>
    </div>
  )
};

export default JSXVariables;
