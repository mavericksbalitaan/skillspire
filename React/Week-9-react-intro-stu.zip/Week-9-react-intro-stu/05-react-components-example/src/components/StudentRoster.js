import React from "react";

const StudentRoster = () => (
  <div>
    <h1>Student Roster</h1>
    <ul>
      <li>D'Andre</li>
      <li>David</li>
      <li>Felix</li>
      <li>Lucci</li>
      <li>Natalie</li>
    </ul>
  </div>
);

export default StudentRoster;
