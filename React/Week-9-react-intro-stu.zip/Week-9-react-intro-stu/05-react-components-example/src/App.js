import './App.css'
import React from "react";
import StudentRoster from "./components/StudentRoster";

const App = () => (
    <>
        <StudentRoster />
    </>
);

export default App;
