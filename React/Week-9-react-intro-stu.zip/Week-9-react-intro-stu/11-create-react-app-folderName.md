npx create-react-app <folder-name>

npx create-react-app monicas-portfolio