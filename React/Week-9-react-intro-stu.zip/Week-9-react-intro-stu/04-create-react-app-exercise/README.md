### Instructions

* In your terminal navigate to your 04-create-react-app folder and run the following command

`npx create-react-app .`


* Start the app by running `npm start` in your terminal, take a moment to study the HTML code being rendered in the browser at [http://localhost:3000](http://localhost:3000).

## 🏆 Bonus

* What are some other flags that you can use with the `create-react-app` utility?