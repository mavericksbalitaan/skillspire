import logo from './logo.svg';
import './App.css';
import Nav from './components/Nav'
import AnotherPage from './AnotherPage';

function App() {
  return (
    <div className="App">
      <Nav />
      <AnotherPage />
    </div>
  );
}

export default App;
