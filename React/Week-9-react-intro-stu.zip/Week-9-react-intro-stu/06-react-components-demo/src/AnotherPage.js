import React from 'react';
import Nav from './components/Nav';

const AnotherPage = () => {

    return(
        <>
            <h1>Another page</h1>
            <Nav />
        </>
    )
}

export default AnotherPage;