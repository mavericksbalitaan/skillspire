import React from "react";

const ThanksgivingMenu = () => (null);

export default ThanksgivingMenu;
