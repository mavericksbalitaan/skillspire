import React from "react";
import ThanksgivingMenu from "./components/ThanksgivingMenu";

const App = () => <ThanksgivingMenu />;

export default App;
