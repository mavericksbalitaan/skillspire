
import ReducerTutorial from "./components/ReducerTutorial";

function App() {
  return (
    <div className="App">
      <ReducerTutorial />
    </div>
  );
}

export default App;