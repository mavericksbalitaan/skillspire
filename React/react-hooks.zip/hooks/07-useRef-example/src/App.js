import React from 'react';

import UseRef from './components/UseRef';

const App = () => {
  return (
    <div className='App'>
      <UseRef />
    </div>
  );
};

export default App;