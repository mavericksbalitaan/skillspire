import React from 'react';

import UseReducerExample from './component/UseReducerExample';

const App = () => {
  return (
    <div className='App'>
      <UseReducerExample />
    </div>
  );
};

export default App;