import React from 'react';
import Thermostat from './components/Thermostat';

const App = () => {
  return <Thermostat />;
}

export default App;
