// We have to first import `useState` with React in order to take advantage of the hook
import React, { useEffect, useState } from "react";

function Greeting() {
  // TODO: Convert `greeting` to a state variable using the useState hook. Give it a initial value of 'Welcome the following students to class!'
  // let greeting = 'Welcome the following students to class!';

  const [greeting, setGreeting] = useState(
    "Welcome the following students to class!"
  );
  const [greeting2, setGreeting2] = useState(
    "Welcome the following teachers to class!"
  );

  // TODO: Convert `group` to a state variable using the useState hook. Set to an initial value to an array including three students in your class. (ex. ["John", "Grace", "Jared"])
  // let group = ['', '', ''];
  const [group, setGroup] = useState(["John", "Grace", "Jared"]);

  // TODO: Create a state variable that holds a list of teachers. Set the initial value to an array of 5 teachers.
  // After you map over the students array, do the same for teachers
  const [teachers, setTeachers] = useState([
    "Teacher A",
    "Teacher B",
    "Teacher C",
    "Teacher D",
    "Teacher E",
  ]);

  // TODO: use useEffect to update the teachers
  useEffect(() => {
    setTeachers([...teachers, "Teacher F"]);
  }, []);

  return (
    <div className="card text-center">
      <div className="card-header bg-primary text-white">State activity!</div>
      <div className="card-body">
        {/* TODO: Fix the `p` tag below to instead render the `greeting` variable */}
        <p className="card-text">{greeting}</p>
        <ul>
          {/* TODO: Fix the list below so that each member of your group is accessed from the `group` array */}
          {group.map((student, i) => {
            return <li key={i}>{student}</li>;
          })}
        </ul>

        <p className="card-text">{greeting2}</p>
        <ul>
          {teachers.map((teacher, idx) => {
            return <li key={idx}>{teacher}</li>;
          })}
        </ul>
      </div>
    </div>
  );
}

export default Greeting;
